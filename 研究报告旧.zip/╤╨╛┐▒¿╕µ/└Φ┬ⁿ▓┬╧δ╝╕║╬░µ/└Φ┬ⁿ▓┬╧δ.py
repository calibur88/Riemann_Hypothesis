#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
import os

SAVE_PATH = "/storage/emulated/0/研究报告/黎曼猜想几何版/"
DATA_FILE = os.path.join(SAVE_PATH, "analysis_data.txt")
CHART_FILE = os.path.join(SAVE_PATH, "research_chart.png")
TRUE_DATA_FILE = os.path.join(SAVE_PATH, "zeros1.txt")

class RiemannCore:
    def __init__(self):
        self.tau = 2 * np.pi
        self.threshold = 2 * np.pi
        
    def sequence(self, start_T, num_steps):
        """生成序列，严格返回num_steps个数据（除非遇到threshold）"""
        if num_steps <= 0:
            return np.array([])
        trajectory = [float(start_T)]
        T = start_T
        for i in range(num_steps - 1):
            if T <= self.threshold:
                print(f"[Warning] T={T:.2f} below threshold at step {i}, stopping early")
                break
            delta = self.tau / np.log(T / self.threshold)
            T += delta
            trajectory.append(T)
        return np.array(trajectory)
    
    def load_reference_limit(self, filepath, limit):
        """
        加载参考文件：
        - 如果文件数据 > limit，截断到limit个
        - 如果文件数据 < limit，返回全部（不管多少）
        - 如果文件不存在，返回None
        """
        if not os.path.exists(filepath):
            return None
        
        data = []
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                for line in f:
                    if len(data) >= limit:  # 多了直接截断
                        break
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parts = line.split()
                    if len(parts) >= 1:
                        try:
                            val = float(parts[-1])
                            data.append(val)
                        except ValueError:
                            continue
            return np.array(data) if data else None
        except Exception as e:
            print(f"[Error] Loading reference: {e}")
            return None

def calculate_metrics(pred, true):
    """计算误差，以较短的为准"""
    min_len = min(len(pred), len(true))
    if min_len == 0:
        return None
    p, t = pred[:min_len], true[:min_len]
    abs_err = np.abs(p - t)
    return {
        'mae': np.mean(abs_err),
        'max_err': np.max(abs_err),
        'mean_rel': np.mean(abs_err / t * 100),
        'corr': np.corrcoef(p, t)[0,1] if len(p) > 1 else 0,
        'compare_len': min_len
    }

def generate_chart(indices, pred, true=None):
    if pred is None or len(pred) == 0:
        return None
    
    # 确保indices长度与pred一致
    if indices is None or len(indices) != len(pred):
        indices = np.arange(1, len(pred) + 1)
    
    n_points = len(pred)
    has_true = (true is not None) and (len(true) > 0)
    if has_true:
        true = np.array(true)
    
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle(f'Riemann Zero Analysis (N={n_points})', fontsize=16, fontweight='bold', y=0.98)
    
    # 图1: 主对比
    ax1 = axes[0, 0]
    ax1.plot(indices, pred, 'b-', linewidth=2, label='Asymptotic Formula', alpha=0.8)
    if has_true:
        # 只绘制有参考数据的部分
        cmp_len = min(len(true), len(pred))
        ax1.scatter(indices[:cmp_len], true[:cmp_len], c='red', s=15, alpha=0.6, 
                   label=f'Reference (n={cmp_len})', zorder=5)
        if cmp_len < len(pred):
            ax1.axvline(x=cmp_len+0.5, color='gray', linestyle='--', alpha=0.5, 
                       label=f'No reference beyond n={cmp_len}')
    ax1.set_xlabel('Index n')
    ax1.set_ylabel('Zero Position T_n')
    ax1.set_title('Approximation vs Reference')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # 图2: 误差（仅在有参考数据的范围内）
    ax2 = axes[0, 1]
    if has_true:
        cmp_len = min(len(true), len(pred))
        if cmp_len > 0:
            errors = np.abs(pred[:cmp_len] - true[:cmp_len])
            ax2.plot(indices[:cmp_len], errors, 'purple', linewidth=2)
            ax2.axhline(y=np.mean(errors), color='red', linestyle='--', 
                       label=f'MAE={np.mean(errors):.4f}')
            ax2.fill_between(indices[:cmp_len], 0, errors, alpha=0.3, color='purple')
            ax2.set_title(f'Error Analysis (first {cmp_len} points)')
            ax2.legend()
    else:
        ax2.text(0.5, 0.5, 'No Reference Data', ha='center', va='center', 
                transform=ax2.transAxes, fontsize=14, color='darkred')
    ax2.set_xlabel('Index n')
    ax2.grid(True, alpha=0.3)
    
    # 图3: 间距（使用全部pred数据）
    ax3 = axes[1, 0]
    if len(pred) > 1:
        pred_diff = np.diff(pred)
        ax3.plot(indices[1:], pred_diff, 'b-', linewidth=2, label='Formula spacing', alpha=0.7)
        if has_true and len(true) > 1:
            cmp_len = min(len(true), len(pred))
            true_diff = np.diff(true[:cmp_len])
            ax3.scatter(indices[1:cmp_len], true_diff, c='red', s=10, alpha=0.6, label='Reference')
        theory = 2 * np.pi / np.log(pred[:-1] / (2 * np.pi))
        ax3.plot(indices[1:], theory, 'g--', linewidth=1.5, label='Theory')
        ax3.set_xlabel('Index n')
        ax3.set_ylabel('Spacing ΔT')
        ax3.set_title('Consecutive Spacing (All Data)')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
    
    # 图4: GUE统计（使用全部pred数据）
    ax4 = axes[1, 1]
    spacings = np.diff(pred)
    ratios = [min(s1,s2)/max(s1,s2) for s1, s2 in zip(spacings[:-1], spacings[1:]) 
             if s1 > 0 and s2 > 0]
    if ratios:
        ax4.hist(ratios, bins=20, density=True, alpha=0.7, color='purple',
                label=f'N={len(ratios)}, μ={np.mean(ratios):.3f}')
        ax4.axvline(0.536, color='red', linestyle='--', label='GUE 0.536')
        ax4.axvline(0.386, color='gray', linestyle=':', label='Poisson 0.386')
        ax4.set_xlabel('Spacing Ratio')
        ax4.set_ylabel('Density')
        ax4.set_title('Nearest-Neighbor Statistics (All Data)')
        ax4.legend()
        ax4.grid(True, alpha=0.3)
    
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    return fig

def save_complete_data(indices, pred, true, metrics, filepath):
    """保存完整数据到txt，所有行都保存"""
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write("RIEMANN ZERO ANALYSIS - COMPLETE DATA\n")
        f.write("="*80 + "\n\n")
        
        total = len(pred)
        ref_len = len(true) if true is not None else 0
        
        f.write(f"Total generated: {total}\n")
        f.write(f"Reference available: {ref_len}\n")
        if metrics:
            f.write(f"Compared points: {metrics['compare_len']}\n")
            f.write(f"MAE: {metrics['mae']:.8f}\n")
            f.write(f"Correlation: {metrics['corr']:.8f}\n")
        f.write("\n")
        
        # 表头
        header = f"{'Index':>8} | {'Predicted':>18} | "
        if ref_len > 0:
            header += f"{'Reference':>18} | {'Abs_Error':>12} | "
        header += f"{'Spacing':>12}\n"
        f.write(header)
        f.write("-"*100 + "\n")
        
        # 写入所有行，不是部分
        for i in range(total):
            spacing = pred[i] - pred[i-1] if i > 0 else 0
            line = f"{int(indices[i]):8d} | {pred[i]:18.10f} | "
            
            if ref_len > 0:
                if i < ref_len:
                    err = abs(pred[i] - true[i])
                    line += f"{true[i]:18.10f} | {err:12.6f} | "
                else:
                    line += f"{'N/A':>18} | {'N/A':>12} | "
            
            line += f"{spacing:12.6f}\n"
            f.write(line)
        
        f.write("-"*100 + "\n")
        f.write(f"End of data ({total} rows)\n")

def main():
    print("="*70)
    print("RIEMANN ZERO ASYMPTOTIC ANALYSIS")
    print("="*70)
    
    if not os.path.exists(SAVE_PATH):
        os.makedirs(SAVE_PATH)
    
    # 配置：固定生成500个，不根据参考文件改变
    NUM_ZEROS = 500  # 固定生成500个
    INITIAL_T = 14.134725
    
    core = RiemannCore()
    
    print(f"\n[Config] Will generate exactly {NUM_ZEROS} zeros")
    
    # 步骤1：加载参考文件（限制最多NUM_ZEROS个，多了截断，少了不管）
    print(f"[Step 1] Loading reference (max {NUM_ZEROS})...")
    ref_data = core.load_reference_limit(TRUE_DATA_FILE, NUM_ZEROS)
    
    if ref_data is None:
        print("  No reference file found, will generate formula only")
        ref_data = np.array([])
    else:
        print(f"  Loaded {len(ref_data)} reference zeros")
        if len(ref_data) < NUM_ZEROS:
            print(f"  [Info] Reference has only {len(ref_data)} points (less than {NUM_ZEROS})")
    
    # 步骤2：生成完整的NUM_ZEROS个数据
    print(f"\n[Step 2] Generating {NUM_ZEROS} zeros...")
    pred = core.sequence(INITIAL_T, NUM_ZEROS)
    
    actual_count = len(pred)
    print(f"  Generated: {actual_count} zeros")
    if actual_count < NUM_ZEROS:
        print(f"  [Warning] Stopped early at {actual_count} (threshold reached)")
    
    # 生成indices确保长度匹配
    indices = np.arange(1, actual_count + 1)
    
    # 步骤3：计算误差（只对齐有效部分，不管谁多谁少）
    metrics = None
    if len(ref_data) > 0:
        cmp_len = min(len(pred), len(ref_data))
        print(f"\n[Step 3] Comparing first {cmp_len} points...")
        metrics = calculate_metrics(pred, ref_data)
        if metrics:
            print(f"  MAE:  {metrics['mae']:.6f}")
            print(f"  Corr: {metrics['corr']:.6f}")
    
    # 步骤4：绘图
    print(f"\n[Step 4] Generating charts...")
    fig = generate_chart(indices, pred, ref_data if len(ref_data) > 0 else None)
    if fig:
        fig.savefig(CHART_FILE, dpi=300, bbox_inches='tight')
        print(f"  Chart saved: {CHART_FILE}")
    
    # 步骤5：保存完整数据（所有行）
    print(f"[Step 5] Saving complete data ({actual_count} rows)...")
    save_complete_data(indices, pred, ref_data, metrics, DATA_FILE)
    print(f"  Data saved: {DATA_FILE}")
    
    # 预览前5行和后5行
    print(f"\n[Preview] First 5 rows:")
    for i in range(min(5, actual_count)):
        print(f"  n={indices[i]}: T={pred[i]:.6f}")
    
    if actual_count > 10:
        print(f"[Preview] Last 5 rows:")
        for i in range(actual_count-5, actual_count):
            print(f"  n={indices[i]}: T={pred[i]:.6f}")
    
    print("\n" + "="*70)
    print(f"Done! Generated {actual_count} complete data points.")
    if len(ref_data) > 0:
        print(f"Reference: {len(ref_data)} points used for comparison.")
    print("="*70)

if __name__ == "__main__":
    main()
